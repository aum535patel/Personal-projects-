import React from 'react';
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom';
import Home from './components/Home';
import About from './components/About';
import Info from './components/Info';
import Contact from './components/Contact';
import './styles/style.css';
function App() {
    return (
        <BrowserRouter>
            <div className="app-container">
                <header>
                    <nav>
                        <Link to="/">Home</Link>
                        <Link to="/about">About Us</Link>
                        <Link to="/info">Information</Link> {/* Adding Basic Info Link */}
                        <Link to="/contact">Contact</Link>
                    </nav>
                </header>
                <Routes>
                    <Route path="/" element={<Home />} />
                    <Route path="/about" element={<About />} />
                    <Route path="/contact" element={<Contact />} />
                    <Route path="/info" element={<Info />} />  {/* Adding Route for Basic Info Page */}
                </Routes>
            </div>
        </BrowserRouter>
    );
}
export default App;