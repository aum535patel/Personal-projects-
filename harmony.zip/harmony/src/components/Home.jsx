import React from 'react';
import { Link } from 'react-router-dom';
import '../styles/style.css';
const courses = [
    { 
        name: "Guitar", 
        description: "Dive into the world of guitar-playing, whether acoustic or electric. Learn chords, scales, fingerstyle techniques, and soloing essentials. Perfect for all skill levels... ", 
        image: "/guitar.jpg",
        infoLink: "/info?course=Guitar"
    },
    { 
        name: "Drum", 
        description: "Feel the power of rhythm with dynamic drum lessons. Master various styles including rock, jazz, and funk, while developing stick control, grooves, fills, and timing... ", 
        image: "/drum.jpg",
        infoLink: "/info?course=Drum"
    },
    { 
        name: "Flute", 
        description: "Experience the graceful sound of the flute through tailored lessons focusing on breath control, tone, and advanced techniques. Explore classical and contemporary pieces... ", 
        image: "/flute.jpg",
        infoLink: "/info?course=Flute"
    },
    { 
        name: "Piano", 
        description: "Discover the magic of piano playing, from classical to jazz and pop. Develop skills in music theory, sight-reading, technique, and expression... ", 
        image: "/piano.jpg",
        infoLink: "/info?course=Piano"
    },
    { 
        name: "Violin", 
        description: "Step into the enchanting world of violin playing. Focus on posture, bowing, intonation, and musicality. Whether classical or modern... ", 
        image: "/violin.jpg",
        infoLink: "/info?course=Violin"
    },
    { 
        name: "Vocals", 
        description: "Unleash your vocal potential with expert coaching. Improve vocal techniques, breath control, pitch, and stage presence... ", 
        image: "/vocals.jpg",
        infoLink: "/info?course=Vocals"
    }
];
const Home = () => {
    return (
        <div className="home-container">
            <section id="welcome">
                <div className="logo-container">
                    <img src="/final_logo.png" alt="Harmony Logo" />
                </div>
                <div className="welcome-text">
                    <p>
                        Discover the joy of music with our expert instructors and comprehensive courses. 
                        Whether you're a beginner or looking to refine your skills, we have the perfect program for you.
                    </p>
                </div>
                <div className="courses-container">
                    {courses.map((course, index) => (
                        <div className="card" key={index}>
                            <div className="card-inner">
                                <div className="card-front">
                                    <img src={course.image} alt={course.name} />
                                    <h3>{course.name}</h3>
                                </div>
                                <div className="card-back">
                                    <p>
                                        {course.description}
                                        <Link to={course.infoLink} style={{ color: 'blue' }}>more</Link>
                                    </p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>
        </div>
    );
};
export default Home;