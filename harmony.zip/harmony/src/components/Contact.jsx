import React from "react";
import "./../styles/style.css";
export default function Contact() {
  return (
    <div className="contact-page">
      <div className="contact-container">
        <h2>Contact Us</h2>
        <p>
          Have questions or want to get in touch? Feel free to reach out to us.
        </p>
        {/* Contact Info Section */}
        <div className="contact-info">
          <p><strong>Contact Numbers:</strong> +1 234 567 8901, +1 987 654 3210</p>
          <p><strong>Email:</strong> harmonyacademy@gmail.com</p>
        </div>
        <form className="contact-form">
          <div className="form-group">
            <label>Name:</label>
            <input type="text" placeholder="Enter your name" />
          </div>
          <div className="form-group">
            <label>Email:</label>
            <input type="email" placeholder="Enter your email" />
          </div>
          <div className="form-group">
            <label>Message:</label>
            <textarea placeholder="Enter your message"></textarea>
          </div>
          <button type="submit">Submit</button>
        </form>
        {/* Social Links Section */}
        <div className="social-links">
          <a href="https://www.instagram.com/youraccount" target="_blank" rel="noopener noreferrer">
            <img src="/insta_logo.png" alt="Instagram" /> Instagram
          </a>
          <a href="https://www.twitter.com/youraccount" target="_blank" rel="noopener noreferrer">
            <img src="/twitter_logo.png" alt="Twitter" /> Twitter (X)
          </a>
        </div>
      </div>
    </div>
  );
}