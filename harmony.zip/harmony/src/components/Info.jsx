import React from 'react';
import { useLocation } from 'react-router-dom';
import '../styles/style.css';
const courseDetails = {
    Guitar: {
        description1: "Master the art of strumming, picking, and fingerpicking with our guitar lessons. Whether you're a beginner just picking up the instrument for the first time or an advanced player looking to refine your technique, our comprehensive courses are designed to guide you every step of the way. From acoustic to electric, we cover a variety of styles and techniques, including basic chords, scales, and more intricate fingerstyle patterns. Learn the essential building blocks of soloing, improvisation, and songwriting to express yourself through this versatile instrument.",
        description2: "Additionally, we delve into music theory, ear training, and rhythm development, ensuring a well-rounded understanding of the guitar. We’ll help you build a strong foundation while encouraging your creative journey, whether you’re aiming to play in a band or simply enjoy playing at home.",
        images: ["/guitar_info1.jpg", "/guitar_info2.jpg"]
    },
    Piano: {
        description1: "Unlock the timeless beauty of the piano through lessons that cater to all ages and skill levels. From beginner to advanced, we offer a structured approach that emphasizes the fundamentals of music theory, sight-reading, and technical proficiency, with a focus on building both your knowledge and your emotional connection to the instrument. Learn to express yourself through classical compositions, jazz improvisation, or popular music—whichever style you prefer.",
        description2: "Our piano courses also include lessons on chord progressions, ear training, and rhythm, giving you the tools to become a versatile performer and songwriter. We’ll help you develop a strong sense of musicality, from mastering finger techniques to understanding complex harmonic structures, ensuring you're confident as both a soloist and an accompanist.",
        images: ["/piano_info1.jpg", "/piano_info2.jpg"]
    },
    Vocals: {
        description1: "Find your voice and unleash your vocal potential with our expert vocal coaching. Whether you're an aspiring singer or an experienced performer, our lessons focus on developing strong vocal techniques, breath control, and pitch accuracy. Through proper warm-ups, vocal exercises, and performance strategies, you'll gain control over your voice and learn how to project and express yourself confidently.",
        description2: "Emphasis is placed on vocal health, resonance, and stage presence, ensuring you not only sing with power and clarity but also captivate your audience. You'll develop a deeper understanding of your vocal range, discover how to express emotion through your voice, and gain the confidence to perform in any setting.",
        images: ["/vocals_info1.jpg", "/vocals_info2.jpg"]
    },
    Drum: {
        description1: "Feel the rhythm and unleash your inner percussionist with our high-energy drum classes. Explore a wide range of styles—from rock and jazz to funk, blues, and even Latin—while mastering essential skills like stick control, drumming techniques, timing, and dynamic range.",
        description2: "Additionally, our classes emphasize the importance of timing, groove, and learning to play with other musicians, preparing you for performances, studio sessions, or simply jamming with friends. Whatever your goals may be, our drum lessons will help you build confidence behind the kit and develop your own unique sound.",
        images: ["/drum_info1.jpg", "/drum_info2.jpg"]
    },
    Flute: {
        description1: "Discover the elegance and grace of the flute with personalized lessons that cater to all skill levels. Our expert instructors will guide you in developing breath control, tone production, and articulation, ensuring you play with precision and beauty.",
        description2: "Through regular practice, you'll refine your technical skills while cultivating a deeper appreciation for the flute as both an expressive and virtuosic instrument.",
        images: ["/flute_info1.jpg", "/flute_info2.jpg"]
    },
    Violin: {
        description1: "Step into the rich world of string instruments with our comprehensive violin lessons. Designed for both beginners and advanced players, our lessons focus on posture, bowing techniques, and intonation to build a solid foundation.",
        description2: "Whether you're preparing for performances or simply enjoying the beauty of the instrument, our lessons will guide you toward musicality, precision, and artistic expression.",
        images: ["/violin_info1.jpg", "/violin_info2.jpg"]
    }
};
const Info = () => {
    const location = useLocation();
    const params = new URLSearchParams(location.search);
    const courseName = params.get("course");
    const course = courseDetails[courseName] || null;

    if (!course) return <div className="content-container">Course not found.</div>;
    return (
        <div className="info-page">
            <div className="info-grid-container">
                <div className="info-box">{course.description1}</div>
                <div className="info-box">
                    <img src={course.images[0]} alt={`${courseName} Image 1`} className="info-image" />
                </div>
                <div className="info-box">
                    <img src={course.images[1]} alt={`${courseName} Image 2`} className="info-image" />
                </div>
                <div className="info-box">{course.description2}</div>
            </div>
        </div>
    );
};
export default Info;