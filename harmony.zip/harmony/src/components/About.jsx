import React from 'react';
import "../styles/style.css";
const About = () => (
    <div className="about-page">
        <div className="about-content-container">
            <h2>🎵 HARMONY MUSIC ACADEMY 🎵</h2>
            
            <div className="about-intro">
                <p>
                    Harmony Music Academy is dedicated to providing high-quality music education to learners of all ages. 
                    Our mission is to nurture musical talent and inspire creativity through a wide range of instrumental courses.
                </p>
                <p>
                    We believe music is a universal language that brings joy and peace to everyone. 
                    Our experienced instructors are here to guide you on your musical journey, whether you are a beginner or an advanced musician.
                </p>
            </div>

            <div className="about-mission">
                <h3>Our Mission</h3>
                <p>
                    To inspire and empower individuals through exceptional music education, fostering creativity, discipline,
                    and a lifelong appreciation for the art of music.
                </p>
            </div>

            <div className="about-vision">
                <h3>Our Vision</h3>
                <p>
                    To be a leading music academy recognized for its commitment to excellence, innovation, and inclusivity 
                    in music education, inspiring generations of musicians worldwide.
                </p>
            </div>
        </div>
    </div>
);
export default About;